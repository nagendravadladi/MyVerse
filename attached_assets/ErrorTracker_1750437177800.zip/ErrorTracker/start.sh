#!/bin/bash
echo "🚀 Starting MyVerse..."
npx tsx server/minimal-server.ts