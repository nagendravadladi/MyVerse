import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import { eq, and, desc } from 'drizzle-orm'
import * as schema from '@shared/schema'
import type {
  User, InsertUser, YoutubeVideo, InsertYoutubeVideo, StudyNote, InsertStudyNote,
  EducationalResource, InsertEducationalResource, GameStats, InsertGameStats,
  MusicPlaylist, InsertMusicPlaylist, WorkoutProgress, InsertWorkoutProgress,
  HealthTip, InsertHealthTip, FoodScan, InsertFoodScan, WatchListItem, InsertWatchListItem,
  WishlistItem, InsertWishlistItem, Budget, InsertBudget, Bill, InsertBill,
  Document, InsertDocument, AiTool, InsertAiTool, QuickShortcut, InsertQuickShortcut,
  DockItem, InsertDockItem
} from '@shared/schema'

// Initialize database connection
const connectionString = process.env.DATABASE_URL || 'postgres://localhost:5432/myverse'
const client = postgres(connectionString)
const db = drizzle(client, { schema })

export interface IStorage {
  // Users
  createUser(user: InsertUser): Promise<User>
  getUserByEmail(email: string): Promise<User | null>
  getUserById(id: number): Promise<User | null>
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>
  
  // YouTube Videos
  createYoutubeVideo(video: InsertYoutubeVideo): Promise<YoutubeVideo>
  getYoutubeVideosByUser(userId: number): Promise<YoutubeVideo[]>
  deleteYoutubeVideo(id: number, userId: number): Promise<void>
  
  // Study Notes
  createStudyNote(note: InsertStudyNote): Promise<StudyNote>
  getStudyNotesByUser(userId: number): Promise<StudyNote[]>
  updateStudyNote(id: number, note: Partial<InsertStudyNote>, userId: number): Promise<StudyNote>
  deleteStudyNote(id: number, userId: number): Promise<void>
  
  // Educational Resources
  createEducationalResource(resource: InsertEducationalResource): Promise<EducationalResource>
  getEducationalResourcesByUser(userId: number): Promise<EducationalResource[]>
  deleteEducationalResource(id: number, userId: number): Promise<void>
  
  // Game Stats
  createOrUpdateGameStats(stats: InsertGameStats): Promise<GameStats>
  getGameStatsByUser(userId: number): Promise<GameStats[]>
  
  // Music Playlists
  createMusicPlaylist(playlist: InsertMusicPlaylist): Promise<MusicPlaylist>
  getMusicPlaylistsByUser(userId: number): Promise<MusicPlaylist[]>
  deleteMusicPlaylist(id: number, userId: number): Promise<void>
  
  // Workout Progress
  createWorkoutProgress(progress: InsertWorkoutProgress): Promise<WorkoutProgress>
  getWorkoutProgressByUser(userId: number): Promise<WorkoutProgress[]>
  getWorkoutProgressByDate(userId: number, date: string): Promise<WorkoutProgress[]>
  
  // Health Tips
  createHealthTip(tip: InsertHealthTip): Promise<HealthTip>
  getHealthTipsByUser(userId: number): Promise<HealthTip[]>
  updateHealthTip(id: number, tip: Partial<InsertHealthTip>, userId: number): Promise<HealthTip>
  
  // Food Scans
  createFoodScan(scan: InsertFoodScan): Promise<FoodScan>
  getFoodScansByUser(userId: number): Promise<FoodScan[]>
  
  // Watch List
  createWatchListItem(item: InsertWatchListItem): Promise<WatchListItem>
  getWatchListByUser(userId: number): Promise<WatchListItem[]>
  updateWatchListItem(id: number, item: Partial<InsertWatchListItem>, userId: number): Promise<WatchListItem>
  deleteWatchListItem(id: number, userId: number): Promise<void>
  
  // Wishlist Items
  createWishlistItem(item: InsertWishlistItem): Promise<WishlistItem>
  getWishlistItemsByUser(userId: number): Promise<WishlistItem[]>
  deleteWishlistItem(id: number, userId: number): Promise<void>
  
  // Budgets
  createBudget(budget: InsertBudget): Promise<Budget>
  getBudgetsByUser(userId: number): Promise<Budget[]>
  updateBudget(id: number, budget: Partial<InsertBudget>, userId: number): Promise<Budget>
  
  // Bills
  createBill(bill: InsertBill): Promise<Bill>
  getBillsByUser(userId: number): Promise<Bill[]>
  updateBill(id: number, bill: Partial<InsertBill>, userId: number): Promise<Bill>
  deleteBill(id: number, userId: number): Promise<void>
  
  // Documents
  createDocument(document: InsertDocument): Promise<Document>
  getDocumentsByUser(userId: number): Promise<Document[]>
  deleteDocument(id: number, userId: number): Promise<void>
  
  // AI Tools
  createAiTool(tool: InsertAiTool): Promise<AiTool>
  getAiToolsByUser(userId: number): Promise<AiTool[]>
  deleteAiTool(id: number, userId: number): Promise<void>
  
  // Quick Shortcuts
  createQuickShortcut(shortcut: InsertQuickShortcut): Promise<QuickShortcut>
  getQuickShortcutsByUser(userId: number): Promise<QuickShortcut[]>
  deleteQuickShortcut(id: number, userId: number): Promise<void>
  
  // Dock Items
  createDockItem(item: InsertDockItem): Promise<DockItem>
  getDockItemsByUser(userId: number): Promise<DockItem[]>
  updateDockItemPosition(id: number, position: number, userId: number): Promise<DockItem>
  deleteDockItem(id: number, userId: number): Promise<void>
}

export class DatabaseStorage implements IStorage {
  // Users
  async createUser(user: InsertUser): Promise<User> {
    const [result] = await db.insert(schema.users).values(user).returning()
    return result
  }

  async getUserByEmail(email: string): Promise<User | null> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email))
    return user || null
  }

  async getUserById(id: number): Promise<User | null> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id))
    return user || null
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    const [result] = await db.update(schema.users).set(user).where(eq(schema.users.id, id)).returning()
    return result
  }

  // YouTube Videos
  async createYoutubeVideo(video: InsertYoutubeVideo): Promise<YoutubeVideo> {
    const [result] = await db.insert(schema.youtubeVideos).values(video).returning()
    return result
  }

  async getYoutubeVideosByUser(userId: number): Promise<YoutubeVideo[]> {
    return await db.select().from(schema.youtubeVideos)
      .where(eq(schema.youtubeVideos.userId, userId))
      .orderBy(desc(schema.youtubeVideos.createdAt))
  }

  async deleteYoutubeVideo(id: number, userId: number): Promise<void> {
    await db.delete(schema.youtubeVideos)
      .where(and(eq(schema.youtubeVideos.id, id), eq(schema.youtubeVideos.userId, userId)))
  }

  // Study Notes
  async createStudyNote(note: InsertStudyNote): Promise<StudyNote> {
    const [result] = await db.insert(schema.studyNotes).values(note).returning()
    return result
  }

  async getStudyNotesByUser(userId: number): Promise<StudyNote[]> {
    return await db.select().from(schema.studyNotes)
      .where(eq(schema.studyNotes.userId, userId))
      .orderBy(desc(schema.studyNotes.updatedAt))
  }

  async updateStudyNote(id: number, note: Partial<InsertStudyNote>, userId: number): Promise<StudyNote> {
    const [result] = await db.update(schema.studyNotes)
      .set({ ...note, updatedAt: new Date() })
      .where(and(eq(schema.studyNotes.id, id), eq(schema.studyNotes.userId, userId)))
      .returning()
    return result
  }

  async deleteStudyNote(id: number, userId: number): Promise<void> {
    await db.delete(schema.studyNotes)
      .where(and(eq(schema.studyNotes.id, id), eq(schema.studyNotes.userId, userId)))
  }

  // Educational Resources
  async createEducationalResource(resource: InsertEducationalResource): Promise<EducationalResource> {
    const [result] = await db.insert(schema.educationalResources).values(resource).returning()
    return result
  }

  async getEducationalResourcesByUser(userId: number): Promise<EducationalResource[]> {
    return await db.select().from(schema.educationalResources)
      .where(eq(schema.educationalResources.userId, userId))
      .orderBy(desc(schema.educationalResources.createdAt))
  }

  async deleteEducationalResource(id: number, userId: number): Promise<void> {
    await db.delete(schema.educationalResources)
      .where(and(eq(schema.educationalResources.id, id), eq(schema.educationalResources.userId, userId)))
  }

  // Game Stats
  async createOrUpdateGameStats(stats: InsertGameStats): Promise<GameStats> {
    const existing = await db.select().from(schema.gameStats)
      .where(and(
        eq(schema.gameStats.userId, stats.userId!),
        eq(schema.gameStats.gameName, stats.gameName)
      ))
    
    if (existing.length > 0) {
      const [result] = await db.update(schema.gameStats)
        .set({ 
          score: stats.score,
          gamesPlayed: (existing[0].gamesPlayed || 0) + 1,
          stars: stats.stars,
          lastPlayed: new Date()
        })
        .where(eq(schema.gameStats.id, existing[0].id))
        .returning()
      return result
    } else {
      const [result] = await db.insert(schema.gameStats).values(stats).returning()
      return result
    }
  }

  async getGameStatsByUser(userId: number): Promise<GameStats[]> {
    return await db.select().from(schema.gameStats)
      .where(eq(schema.gameStats.userId, userId))
      .orderBy(desc(schema.gameStats.lastPlayed))
  }

  // Music Playlists
  async createMusicPlaylist(playlist: InsertMusicPlaylist): Promise<MusicPlaylist> {
    const [result] = await db.insert(schema.musicPlaylists).values(playlist).returning()
    return result
  }

  async getMusicPlaylistsByUser(userId: number): Promise<MusicPlaylist[]> {
    return await db.select().from(schema.musicPlaylists)
      .where(eq(schema.musicPlaylists.userId, userId))
      .orderBy(desc(schema.musicPlaylists.createdAt))
  }

  async deleteMusicPlaylist(id: number, userId: number): Promise<void> {
    await db.delete(schema.musicPlaylists)
      .where(and(eq(schema.musicPlaylists.id, id), eq(schema.musicPlaylists.userId, userId)))
  }

  // Workout Progress
  async createWorkoutProgress(progress: InsertWorkoutProgress): Promise<WorkoutProgress> {
    const [result] = await db.insert(schema.workoutProgress).values(progress).returning()
    return result
  }

  async getWorkoutProgressByUser(userId: number): Promise<WorkoutProgress[]> {
    return await db.select().from(schema.workoutProgress)
      .where(eq(schema.workoutProgress.userId, userId))
      .orderBy(desc(schema.workoutProgress.date))
  }

  async getWorkoutProgressByDate(userId: number, date: string): Promise<WorkoutProgress[]> {
    return await db.select().from(schema.workoutProgress)
      .where(and(
        eq(schema.workoutProgress.userId, userId),
        eq(schema.workoutProgress.date, new Date(date))
      ))
  }

  // Health Tips
  async createHealthTip(tip: InsertHealthTip): Promise<HealthTip> {
    const [result] = await db.insert(schema.healthTips).values(tip).returning()
    return result
  }

  async getHealthTipsByUser(userId: number): Promise<HealthTip[]> {
    return await db.select().from(schema.healthTips)
      .where(eq(schema.healthTips.userId, userId))
      .orderBy(desc(schema.healthTips.createdAt))
  }

  async updateHealthTip(id: number, tip: Partial<InsertHealthTip>, userId: number): Promise<HealthTip> {
    const [result] = await db.update(schema.healthTips)
      .set(tip)
      .where(and(eq(schema.healthTips.id, id), eq(schema.healthTips.userId, userId)))
      .returning()
    return result
  }

  // Food Scans
  async createFoodScan(scan: InsertFoodScan): Promise<FoodScan> {
    const [result] = await db.insert(schema.foodScans).values(scan).returning()
    return result
  }

  async getFoodScansByUser(userId: number): Promise<FoodScan[]> {
    return await db.select().from(schema.foodScans)
      .where(eq(schema.foodScans.userId, userId))
      .orderBy(desc(schema.foodScans.scannedAt))
  }

  // Watch List
  async createWatchListItem(item: InsertWatchListItem): Promise<WatchListItem> {
    const [result] = await db.insert(schema.watchList).values(item).returning()
    return result
  }

  async getWatchListByUser(userId: number): Promise<WatchListItem[]> {
    return await db.select().from(schema.watchList)
      .where(eq(schema.watchList.userId, userId))
      .orderBy(desc(schema.watchList.createdAt))
  }

  async updateWatchListItem(id: number, item: Partial<InsertWatchListItem>, userId: number): Promise<WatchListItem> {
    const [result] = await db.update(schema.watchList)
      .set(item)
      .where(and(eq(schema.watchList.id, id), eq(schema.watchList.userId, userId)))
      .returning()
    return result
  }

  async deleteWatchListItem(id: number, userId: number): Promise<void> {
    await db.delete(schema.watchList)
      .where(and(eq(schema.watchList.id, id), eq(schema.watchList.userId, userId)))
  }

  // Wishlist Items
  async createWishlistItem(item: InsertWishlistItem): Promise<WishlistItem> {
    const [result] = await db.insert(schema.wishlistItems).values(item).returning()
    return result
  }

  async getWishlistItemsByUser(userId: number): Promise<WishlistItem[]> {
    return await db.select().from(schema.wishlistItems)
      .where(eq(schema.wishlistItems.userId, userId))
      .orderBy(desc(schema.wishlistItems.createdAt))
  }

  async deleteWishlistItem(id: number, userId: number): Promise<void> {
    await db.delete(schema.wishlistItems)
      .where(and(eq(schema.wishlistItems.id, id), eq(schema.wishlistItems.userId, userId)))
  }

  // Budgets
  async createBudget(budget: InsertBudget): Promise<Budget> {
    const [result] = await db.insert(schema.budgets).values(budget).returning()
    return result
  }

  async getBudgetsByUser(userId: number): Promise<Budget[]> {
    return await db.select().from(schema.budgets)
      .where(eq(schema.budgets.userId, userId))
      .orderBy(desc(schema.budgets.createdAt))
  }

  async updateBudget(id: number, budget: Partial<InsertBudget>, userId: number): Promise<Budget> {
    const [result] = await db.update(schema.budgets)
      .set(budget)
      .where(and(eq(schema.budgets.id, id), eq(schema.budgets.userId, userId)))
      .returning()
    return result
  }

  // Bills
  async createBill(bill: InsertBill): Promise<Bill> {
    const [result] = await db.insert(schema.bills).values(bill).returning()
    return result
  }

  async getBillsByUser(userId: number): Promise<Bill[]> {
    return await db.select().from(schema.bills)
      .where(eq(schema.bills.userId, userId))
      .orderBy(desc(schema.bills.dueDate))
  }

  async updateBill(id: number, bill: Partial<InsertBill>, userId: number): Promise<Bill> {
    const [result] = await db.update(schema.bills)
      .set(bill)
      .where(and(eq(schema.bills.id, id), eq(schema.bills.userId, userId)))
      .returning()
    return result
  }

  async deleteBill(id: number, userId: number): Promise<void> {
    await db.delete(schema.bills)
      .where(and(eq(schema.bills.id, id), eq(schema.bills.userId, userId)))
  }

  // Documents
  async createDocument(document: InsertDocument): Promise<Document> {
    const [result] = await db.insert(schema.documents).values(document).returning()
    return result
  }

  async getDocumentsByUser(userId: number): Promise<Document[]> {
    return await db.select().from(schema.documents)
      .where(eq(schema.documents.userId, userId))
      .orderBy(desc(schema.documents.uploadedAt))
  }

  async deleteDocument(id: number, userId: number): Promise<void> {
    await db.delete(schema.documents)
      .where(and(eq(schema.documents.id, id), eq(schema.documents.userId, userId)))
  }

  // AI Tools
  async createAiTool(tool: InsertAiTool): Promise<AiTool> {
    const [result] = await db.insert(schema.aiTools).values(tool).returning()
    return result
  }

  async getAiToolsByUser(userId: number): Promise<AiTool[]> {
    return await db.select().from(schema.aiTools)
      .where(eq(schema.aiTools.userId, userId))
      .orderBy(desc(schema.aiTools.createdAt))
  }

  async deleteAiTool(id: number, userId: number): Promise<void> {
    await db.delete(schema.aiTools)
      .where(and(eq(schema.aiTools.id, id), eq(schema.aiTools.userId, userId)))
  }

  // Quick Shortcuts
  async createQuickShortcut(shortcut: InsertQuickShortcut): Promise<QuickShortcut> {
    const [result] = await db.insert(schema.quickShortcuts).values(shortcut).returning()
    return result
  }

  async getQuickShortcutsByUser(userId: number): Promise<QuickShortcut[]> {
    return await db.select().from(schema.quickShortcuts)
      .where(eq(schema.quickShortcuts.userId, userId))
      .orderBy(desc(schema.quickShortcuts.createdAt))
  }

  async deleteQuickShortcut(id: number, userId: number): Promise<void> {
    await db.delete(schema.quickShortcuts)
      .where(and(eq(schema.quickShortcuts.id, id), eq(schema.quickShortcuts.userId, userId)))
  }

  // Dock Items
  async createDockItem(item: InsertDockItem): Promise<DockItem> {
    const [result] = await db.insert(schema.dockItems).values(item).returning()
    return result
  }

  async getDockItemsByUser(userId: number): Promise<DockItem[]> {
    return await db.select().from(schema.dockItems)
      .where(eq(schema.dockItems.userId, userId))
      .orderBy(desc(schema.dockItems.position))
  }

  async updateDockItemPosition(id: number, position: number, userId: number): Promise<DockItem> {
    const [result] = await db.update(schema.dockItems)
      .set({ position })
      .where(and(eq(schema.dockItems.id, id), eq(schema.dockItems.userId, userId)))
      .returning()
    return result
  }

  async deleteDockItem(id: number, userId: number): Promise<void> {
    await db.delete(schema.dockItems)
      .where(and(eq(schema.dockItems.id, id), eq(schema.dockItems.userId, userId)))
  }
}

export const storage = new DatabaseStorage()