import express from 'express'
import { z } from 'zod'
import { storage } from './storage'
import * as schema from '@shared/schema'

const router = express.Router()

// Helper function to validate request body
const validateBody = <T>(schema: z.ZodSchema<T>) => {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    try {
      req.body = schema.parse(req.body)
      next()
    } catch (error) {
      res.status(400).json({ error: 'Invalid request body', details: error })
    }
  }
}

// Users
router.post('/users', async (req, res) => {
  try {
    const user = await storage.createUser(req.body)
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to create user' })
  }
})

router.get('/users/by-email/:email', async (req, res) => {
  try {
    const user = await storage.getUserByEmail(decodeURIComponent(req.params.email))
    if (!user) {
      return res.status(404).json({ error: 'User not found' })
    }
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to get user' })
  }
})

router.patch('/users/:id', async (req, res) => {
  try {
    const user = await storage.updateUser(parseInt(req.params.id), req.body)
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to update user' })
  }
})

// YouTube Videos
router.post('/youtube-videos', async (req, res) => {
  try {
    const video = await storage.createYoutubeVideo(req.body)
    res.json(video)
  } catch (error) {
    res.status(500).json({ error: 'Failed to create video' })
  }
})

router.get('/youtube-videos/:userId', async (req, res) => {
  try {
    const videos = await storage.getYoutubeVideosByUser(parseInt(req.params.userId))
    res.json(videos)
  } catch (error) {
    res.status(500).json({ error: 'Failed to get videos' })
  }
})

router.delete('/youtube-videos/:id/:userId', async (req, res) => {
  try {
    await storage.deleteYoutubeVideo(parseInt(req.params.id), parseInt(req.params.userId))
    res.json({ success: true })
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete video' })
  }
})

// Study Notes
router.post('/study-notes', async (req, res) => {
  try {
    const note = await storage.createStudyNote(req.body)
    res.json(note)
  } catch (error) {
    res.status(500).json({ error: 'Failed to create note' })
  }
})

router.get('/study-notes/:userId', async (req, res) => {
  try {
    const notes = await storage.getStudyNotesByUser(parseInt(req.params.userId))
    res.json(notes)
  } catch (error) {
    res.status(500).json({ error: 'Failed to get notes' })
  }
})

router.patch('/study-notes/:id/:userId', async (req, res) => {
  try {
    const note = await storage.updateStudyNote(parseInt(req.params.id), req.body, parseInt(req.params.userId))
    res.json(note)
  } catch (error) {
    res.status(500).json({ error: 'Failed to update note' })
  }
})

router.delete('/study-notes/:id/:userId', async (req, res) => {
  try {
    await storage.deleteStudyNote(parseInt(req.params.id), parseInt(req.params.userId))
    res.json({ success: true })
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete note' })
  }
})

// Educational Resources
router.post('/educational-resources', async (req, res) => {
  try {
    const resource = await storage.createEducationalResource(req.body)
    res.json(resource)
  } catch (error) {
    res.status(500).json({ error: 'Failed to create resource' })
  }
})

router.get('/educational-resources/:userId', async (req, res) => {
  try {
    const resources = await storage.getEducationalResourcesByUser(parseInt(req.params.userId))
    res.json(resources)
  } catch (error) {
    res.status(500).json({ error: 'Failed to get resources' })
  }
})

router.delete('/educational-resources/:id/:userId', async (req, res) => {
  try {
    await storage.deleteEducationalResource(parseInt(req.params.id), parseInt(req.params.userId))
    res.json({ success: true })
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete resource' })
  }
})

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'MyVerse API is running' })
})

export default router