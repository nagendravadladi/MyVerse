import express from 'express'
import cors from 'cors'
import path from 'path'
import { fileURLToPath } from 'url'
import { storage } from './storage'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ extended: true, limit: '50mb' }))

// Serve static files
app.use(express.static(path.join(__dirname, '../')))

// Basic API routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'MyVerse API is running' })
})

app.post('/api/users', async (req, res) => {
  try {
    const user = await storage.createUser(req.body)
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to create user' })
  }
})

app.get('/api/users/by-email/:email', async (req, res) => {
  try {
    const email = decodeURIComponent(req.params.email)
    const user = await storage.getUserByEmail(email)
    if (!user) {
      return res.status(404).json({ error: 'User not found' })
    }
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to get user' })
  }
})

app.patch('/api/users/:id', async (req, res) => {
  try {
    const user = await storage.updateUser(parseInt(req.params.id), req.body)
    res.json(user)
  } catch (error) {
    res.status(500).json({ error: 'Failed to update user' })
  }
})

// Serve the React app for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '../index.html'))
  }
})

app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`🚀 MyVerse server running on http://localhost:${PORT}`)
  console.log(`📱 Frontend available at http://localhost:${PORT}`)
  console.log(`🔌 API endpoints at http://localhost:${PORT}/api`)
})