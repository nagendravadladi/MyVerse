import express from 'express'
import cors from 'cors'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '../')))

// Simple health check without parameters
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'MyVerse API is running' })
})

// Serve React app for all other routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../index.html'))
})

app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`🚀 MyVerse server running on http://localhost:${PORT}`)
  console.log(`📱 Frontend available at http://localhost:${PORT}`)
})