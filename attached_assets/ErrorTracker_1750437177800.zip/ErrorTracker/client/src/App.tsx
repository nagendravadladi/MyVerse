import { QueryClientProvider } from '@tanstack/react-query'
import { Route, Router } from 'wouter'
import { Toaster } from 'react-hot-toast'
import { queryClient } from '@/lib/queryClient'
import { AuthProvider } from '@/hooks/useAuth'
import Dashboard from '@/pages/Dashboard'
import Login from '@/pages/Login'
import './index.css'

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <Route path="/" component={Dashboard} />
          <Route path="/login" component={Login} />
        </Router>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: 'hsl(var(--background))',
              color: 'hsl(var(--foreground))',
              border: '1px solid hsl(var(--border))',
            },
          }}
        />
      </AuthProvider>
    </QueryClientProvider>
  )
}

export default App