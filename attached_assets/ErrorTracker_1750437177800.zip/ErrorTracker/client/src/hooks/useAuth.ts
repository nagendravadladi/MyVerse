import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { apiRequest } from '@/lib/queryClient'
import type { User, InsertUser } from '@shared/schema'

interface AuthContextType {
  user: User | null
  login: (email: string) => Promise<void>
  logout: () => void
  updateUser: (updates: Partial<InsertUser>) => Promise<void>
  isLoading: boolean
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing user in localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('myverse-user')
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (error) {
        localStorage.removeItem('myverse-user')
      }
    }
    setIsLoading(false)
  }, [])

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: (userData: InsertUser) => apiRequest('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    }),
    onSuccess: (newUser: User) => {
      setUser(newUser)
      localStorage.setItem('myverse-user', JSON.stringify(newUser))
    }
  })

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: Partial<InsertUser> }) => 
      apiRequest(`/api/users/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      }),
    onSuccess: (updatedUser: User) => {
      setUser(updatedUser)
      localStorage.setItem('myverse-user', JSON.stringify(updatedUser))
    }
  })

  const login = async (email: string) => {
    setIsLoading(true)
    try {
      // Try to find existing user
      const existingUser = await apiRequest(`/api/users/by-email/${encodeURIComponent(email)}`)
      setUser(existingUser)
      localStorage.setItem('myverse-user', JSON.stringify(existingUser))
    } catch (error) {
      // User doesn't exist, create new one
      const newUserData: InsertUser = {
        email,
        name: email.split('@')[0], // Use email prefix as default name
        profileImage: null,
        dailyQuote: null,
        portfolioLink: null,
        theme: 'light',
        focusMode: false
      }
      await createUserMutation.mutateAsync(newUserData)
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('myverse-user')
  }

  const updateUser = async (updates: Partial<InsertUser>) => {
    if (!user) throw new Error('No user logged in')
    await updateUserMutation.mutateAsync({ id: user.id, updates })
  }

  const value: AuthContextType = {
    user,
    login,
    logout,
    updateUser,
    isLoading: isLoading || createUserMutation.isPending || updateUserMutation.isPending,
    isAuthenticated: !!user
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}