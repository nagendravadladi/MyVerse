import { useAuth } from '@/hooks/useAuth'
import { useLocation } from 'wouter'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { 
  BookOpen, 
  Gamepad2, 
  Music, 
  Dumbbell, 
  Heart, 
  Bot, 
  Play, 
  ShoppingCart, 
  DollarSign,
  FileText,
  Zap,
  Link,
  Home,
  Settings,
  BarChart3,
  Users,
  Plus,
  Star,
  Eye,
  EyeOff,
  Sun,
  Moon,
  LogOut,
  User,
  ExternalLink
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { generateQuote } from '@/lib/utils'

export default function Dashboard() {
  const { user, logout, updateUser, isLoading } = useAuth()
  const [, setLocation] = useLocation()
  const [focusMode, setFocusMode] = useState(false)
  const [theme, setTheme] = useState<'light' | 'dark'>('dark')

  useEffect(() => {
    if (!user && !isLoading) {
      setLocation('/login')
    }
  }, [user, isLoading, setLocation])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark'
    setTheme(newTheme)
    document.documentElement.className = newTheme
    updateUser({ theme: newTheme })
  }

  const toggleFocusMode = () => {
    const newFocusMode = !focusMode
    setFocusMode(newFocusMode)
    updateUser({ focusMode: newFocusMode })
  }

  return (
    <div className={cn("min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900", 
      focusMode && "focus-mode"
    )}>
      {/* Header Section */}
      <header className="p-6 border-b border-white/10 glass">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center">
              {user.profileImage ? (
                <img src={user.profileImage} alt={user.name} className="w-full h-full rounded-full object-cover" />
              ) : (
                <User className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Welcome back, {user.name}!</h1>
              <p className="text-gray-300 text-sm">
                {user.dailyQuote || generateQuote()}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="text-white hover:bg-white/10"
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            
            <Button
              variant={focusMode ? "default" : "ghost"}
              onClick={toggleFocusMode}
              className="text-white"
            >
              {focusMode ? <Eye className="w-4 h-4 mr-2" /> : <EyeOff className="w-4 h-4 mr-2" />}
              Focus Mode
            </Button>
            
            {user.portfolioLink && (
              <a 
                href={user.portfolioLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white hover:bg-white/10 rounded-md transition-colors"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Portfolio
              </a>
            )}
            
            <Button variant="ghost" onClick={logout} className="text-white">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Dashboard Grid */}
      <main className="p-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Study Zone Section */}
          <Card className={cn("col-span-full lg:col-span-2 glass card-hover study-section", 
            focusMode && "pulse-glow"
          )}>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <BookOpen className="w-6 h-6 mr-2" />
                StudyZone
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* YouTube Playlists */}
              <div className="bg-white/5 rounded-lg p-3">
                <h3 className="text-white font-medium mb-2 text-sm flex items-center">
                  <Play className="w-3 h-3 mr-1" />
                  YouTube Playlists
                </h3>
                <div className="flex space-x-1 mb-2">
                  <Input placeholder="Video URL" className="flex-1 h-8 text-xs" />
                  <Input placeholder="Title" className="flex-1 h-8 text-xs" />
                  <Button size="sm" className="h-8 w-8 p-0">
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-1">
                  <div className="aspect-video bg-gray-700 rounded flex items-center justify-center text-gray-400 text-xs">
                    Add videos
                  </div>
                </div>
              </div>

              {/* Study Notes */}
              <div className="bg-white/5 rounded-lg p-3">
                <h3 className="text-white font-medium mb-2 text-sm flex items-center">
                  <FileText className="w-3 h-3 mr-1" />
                  Study Notes
                </h3>
                <div className="flex space-x-1 mb-2">
                  <Input placeholder="Note title" className="flex-1 h-8 text-xs" />
                  <Button size="sm" className="h-8 w-8 p-0">
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <div className="space-y-1">
                  <div className="bg-gray-700 rounded p-2 text-xs text-gray-300">
                    Your notes will appear here
                  </div>
                </div>
              </div>

              {/* Educational Resources */}
              <div className="bg-white/5 rounded-lg p-3">
                <h3 className="text-white font-medium mb-2 text-sm flex items-center">
                  <Link className="w-3 h-3 mr-1" />
                  Educational Resources
                </h3>
                <div className="flex space-x-1 mb-2">
                  <Input placeholder="Resource URL" className="flex-1 h-8 text-xs" />
                  <Input placeholder="Title" className="flex-1 h-8 text-xs" />
                  <Button size="sm" className="h-8 w-8 p-0">
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-1">
                  <div className="bg-gray-700 rounded p-2 text-xs text-gray-300 text-center">
                    Add resources
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Games Section */}
          <Card className={cn("glass card-hover games-section", 
            focusMode && "opacity-30 pointer-events-none"
          )}>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Gamepad2 className="w-6 h-6 mr-2" />
                Games
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {['Tic Tac Toe', 'Snake', 'Tetris', '2048', 'Memory'].map((game) => (
                  <div key={game} className="bg-white/5 rounded-lg p-3 text-center hover:bg-white/10 transition-colors cursor-pointer">
                    <Gamepad2 className="w-8 h-8 mx-auto mb-2 text-purple-400" />
                    <p className="text-white text-sm font-medium">{game}</p>
                    <div className="flex justify-center mt-1">
                      {[...Array(3)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Music Section */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Music className="w-6 h-6 mr-2" />
                Music
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex space-x-2">
                  <Input placeholder="Playlist URL" className="flex-1" />
                  <Button size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <p className="text-white text-sm">Audio Player</p>
                  <div className="bg-gray-700 rounded mt-2 h-8 flex items-center justify-center">
                    <Music className="w-4 h-4 text-gray-400" />
                  </div>
                </div>
                <div className="space-y-2">
                  {['My Favorites', 'Study Mix', 'Workout'].map((playlist) => (
                    <div key={playlist} className="bg-white/5 rounded p-2 flex items-center justify-between">
                      <span className="text-white text-sm">{playlist}</span>
                      <Play className="w-4 h-4 text-purple-400" />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Gym Zone */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Dumbbell className="w-6 h-6 mr-2" />
                Gym Zone
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-2">
                  {['Chest', 'Back', 'Legs', 'Arms', 'Shoulders', 'Core'].map((group) => (
                    <div key={group} className="bg-white/5 rounded p-2 text-center hover:bg-white/10 transition-colors cursor-pointer">
                      <p className="text-white text-xs font-medium">{group}</p>
                      <div className="w-full bg-gray-700 rounded-full h-1 mt-1">
                        <div className="bg-green-400 h-1 rounded-full w-3/4"></div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <p className="text-white text-sm mb-2">Today's Progress</p>
                  <div className="flex justify-between text-xs text-gray-300">
                    <span>Completed: 5</span>
                    <span>Skipped: 1</span>
                    <span>Remaining: 4</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Tracker */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Heart className="w-6 h-6 mr-2" />
                Health Tracker
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-white/5 rounded-lg p-3">
                  <p className="text-white text-sm font-medium mb-2">Daily Tip</p>
                  <p className="text-gray-300 text-xs">Drink 8 glasses of water daily for optimal hydration.</p>
                </div>
                <div className="flex space-x-2">
                  <Input placeholder="Scan food item" className="flex-1" />
                  <Button size="sm">Scan</Button>
                </div>
                <div className="space-y-2">
                  {['Apple - Healthy', 'Chips - Not Recommended'].map((item, i) => (
                    <div key={item} className={cn("rounded p-2 text-xs", 
                      i === 0 ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"
                    )}>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Assistant */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Bot className="w-6 h-6 mr-2" />
                AI Assistant
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-white/5 rounded-lg p-3 h-32 overflow-y-auto">
                  <div className="text-gray-300 text-sm">
                    <p className="mb-2">👋 Hi! I'm here to help you navigate MyVerse.</p>
                    <p>Ask me about any features or how to use the dashboard!</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Input placeholder="Ask about MyVerse..." className="flex-1" />
                  <Button size="sm">Send</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Entertainment Zone */}
          <Card className={cn("glass card-hover social-section", 
            focusMode && "opacity-30 pointer-events-none"
          )}>
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Play className="w-6 h-6 mr-2" />
                Entertainment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex space-x-2">
                  <Input placeholder="Movie/Series URL" className="flex-1" />
                  <Button size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {['Netflix Series', 'Prime Video Movie', 'YouTube Documentary'].map((item) => (
                    <div key={item} className="bg-white/5 rounded p-2 flex items-center justify-between">
                      <span className="text-white text-sm">{item}</span>
                      <Button size="sm" variant="ghost">Watch</Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Ecommerce Wishlist */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <ShoppingCart className="w-6 h-6 mr-2" />
                Wishlist
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex space-x-2">
                  <Input placeholder="Product URL" className="flex-1" />
                  <Button size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  {[
                    { name: 'Laptop', price: '$999', site: 'Amazon', priority: 'High' },
                    { name: 'Book', price: '$15', site: 'Flipkart', priority: 'Medium' }
                  ].map((item, i) => (
                    <div key={i} className="bg-white/5 rounded p-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-white text-sm font-medium">{item.name}</p>
                          <p className="text-gray-300 text-xs">{item.site} • {item.price}</p>
                        </div>
                        <span className={cn("text-xs px-2 py-1 rounded", 
                          item.priority === 'High' ? "bg-red-500/20 text-red-300" : "bg-yellow-500/20 text-yellow-300"
                        )}>
                          {item.priority}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Finance Hub */}
          <Card className="glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <DollarSign className="w-6 h-6 mr-2" />
                Finance Hub
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-white/5 rounded-lg p-3">
                  <p className="text-white text-sm font-medium mb-2">This Month</p>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Income:</span>
                      <span className="text-green-300">$3,000</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Expenses:</span>
                      <span className="text-red-300">$2,100</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Savings:</span>
                      <span className="text-blue-300">$900</span>
                    </div>
                  </div>
                </div>
                <div className="bg-white/5 rounded-lg p-3">
                  <p className="text-white text-sm font-medium mb-2">Upcoming Bills</p>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Rent</span>
                      <span className="text-orange-300">Due in 3 days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Internet</span>
                      <span className="text-orange-300">Due in 5 days</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Shortcuts & Other Sections */}
          <Card className="col-span-full glass card-hover">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Zap className="w-6 h-6 mr-2" />
                Quick Access
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {[
                  { name: 'Documents', icon: FileText, color: 'text-blue-400' },
                  { name: 'AI Tools', icon: Bot, color: 'text-purple-400' },
                  { name: 'Analytics', icon: BarChart3, color: 'text-green-400' },
                  { name: 'Social', icon: Users, color: 'text-pink-400' },
                  { name: 'Settings', icon: Settings, color: 'text-gray-400' },
                  { name: 'Shortcuts', icon: Zap, color: 'text-yellow-400' }
                ].map((item) => (
                  <div key={item.name} className="bg-white/5 rounded-lg p-4 text-center hover:bg-white/10 transition-colors cursor-pointer">
                    <item.icon className={cn("w-8 h-8 mx-auto mb-2", item.color)} />
                    <p className="text-white text-sm font-medium">{item.name}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Floating Dock */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 dock rounded-full px-6 py-3">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <Home className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <BookOpen className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <Gamepad2 className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <Music className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <DollarSign className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}