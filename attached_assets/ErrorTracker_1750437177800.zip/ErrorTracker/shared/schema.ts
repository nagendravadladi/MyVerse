import { pgTable, text, integer, boolean, timestamp, json, serial } from 'drizzle-orm/pg-core'
import { createInsertSchema } from 'drizzle-zod'
import { z } from 'zod'

// Users table for authentication and profile
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: text('email').notNull().unique(),
  name: text('name').notNull(),
  profileImage: text('profile_image'),
  dailyQuote: text('daily_quote'),
  portfolioLink: text('portfolio_link'),
  theme: text('theme').default('light'),
  focusMode: boolean('focus_mode').default(false),
  createdAt: timestamp('created_at').defaultNow(),
})

// Study Zone - YouTube Playlists
export const youtubeVideos = pgTable('youtube_videos', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  videoUrl: text('video_url').notNull(),
  thumbnail: text('thumbnail'),
  topic: text('topic'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Study Zone - Notes
export const studyNotes = pgTable('study_notes', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

// Study Zone - Educational Resources
export const educationalResources = pgTable('educational_resources', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  previewImage: text('preview_image'),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Games - Game Stats
export const gameStats = pgTable('game_stats', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  gameName: text('game_name').notNull(),
  score: integer('score').default(0),
  gamesPlayed: integer('games_played').default(0),
  stars: integer('stars').default(0),
  lastPlayed: timestamp('last_played').defaultNow(),
})

// Music - Playlists
export const musicPlaylists = pgTable('music_playlists', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  platform: text('platform'),
  thumbnail: text('thumbnail'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Gym Zone - Workout Progress
export const workoutProgress = pgTable('workout_progress', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  muscleGroup: text('muscle_group').notNull(),
  exerciseName: text('exercise_name').notNull(),
  status: text('status').notNull(), // 'completed', 'skipped', 'pending'
  date: timestamp('date').defaultNow(),
})

// Health Tracker - Daily Tips
export const healthTips = pgTable('health_tips', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  tip: text('tip').notNull(),
  category: text('category'),
  saved: boolean('saved').default(false),
  createdAt: timestamp('created_at').defaultNow(),
})

// Health Tracker - Food Scans
export const foodScans = pgTable('food_scans', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  foodName: text('food_name').notNull(),
  healthRating: text('health_rating').notNull(), // 'healthy', 'not_recommended'
  scannedAt: timestamp('scanned_at').defaultNow(),
})

// Entertainment - Watch List
export const watchList = pgTable('watch_list', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  thumbnail: text('thumbnail'),
  platform: text('platform'),
  watched: boolean('watched').default(false),
  createdAt: timestamp('created_at').defaultNow(),
})

// Ecommerce Wishlist
export const wishlistItems = pgTable('wishlist_items', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  productName: text('product_name').notNull(),
  price: text('price'),
  productUrl: text('product_url').notNull(),
  imageUrl: text('image_url'),
  website: text('website').notNull(),
  priority: text('priority').default('medium'),
  category: text('category'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Finance Hub - Budgets
export const budgets = pgTable('budgets', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  month: text('month').notNull(),
  monthlyIncome: integer('monthly_income').notNull(),
  plannedExpenses: integer('planned_expenses').notNull(),
  realExpenses: integer('real_expenses').default(0),
  createdAt: timestamp('created_at').defaultNow(),
})

// Finance Hub - Bills
export const bills = pgTable('bills', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  billName: text('bill_name').notNull(),
  amount: integer('amount').notNull(),
  dueDate: timestamp('due_date').notNull(),
  paid: boolean('paid').default(false),
  recurring: boolean('recurring').default(false),
  createdAt: timestamp('created_at').defaultNow(),
})

// Important Documents
export const documents = pgTable('documents', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  fileType: text('file_type').notNull(),
  fileUrl: text('file_url'),
  tags: text('tags').array(),
  uploadedAt: timestamp('uploaded_at').defaultNow(),
})

// AI Tools
export const aiTools = pgTable('ai_tools', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  name: text('name').notNull(),
  url: text('url').notNull(),
  icon: text('icon'),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Quick Shortcuts
export const quickShortcuts = pgTable('quick_shortcuts', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  icon: text('icon'),
  createdAt: timestamp('created_at').defaultNow(),
})

// Dock Items (Pinned Apps)
export const dockItems = pgTable('dock_items', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text('title').notNull(),
  url: text('url').notNull(),
  icon: text('icon'),
  section: text('section').notNull(),
  position: integer('position').default(0),
  createdAt: timestamp('created_at').defaultNow(),
})

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true })
export const insertYoutubeVideoSchema = createInsertSchema(youtubeVideos).omit({ id: true, createdAt: true })
export const insertStudyNoteSchema = createInsertSchema(studyNotes).omit({ id: true, createdAt: true, updatedAt: true })
export const insertEducationalResourceSchema = createInsertSchema(educationalResources).omit({ id: true, createdAt: true })
export const insertGameStatsSchema = createInsertSchema(gameStats).omit({ id: true, lastPlayed: true })
export const insertMusicPlaylistSchema = createInsertSchema(musicPlaylists).omit({ id: true, createdAt: true })
export const insertWorkoutProgressSchema = createInsertSchema(workoutProgress).omit({ id: true, date: true })
export const insertHealthTipSchema = createInsertSchema(healthTips).omit({ id: true, createdAt: true })
export const insertFoodScanSchema = createInsertSchema(foodScans).omit({ id: true, scannedAt: true })
export const insertWatchListSchema = createInsertSchema(watchList).omit({ id: true, createdAt: true })
export const insertWishlistItemSchema = createInsertSchema(wishlistItems).omit({ id: true, createdAt: true })
export const insertBudgetSchema = createInsertSchema(budgets).omit({ id: true, createdAt: true })
export const insertBillSchema = createInsertSchema(bills).omit({ id: true, createdAt: true })
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, uploadedAt: true })
export const insertAiToolSchema = createInsertSchema(aiTools).omit({ id: true, createdAt: true })
export const insertQuickShortcutSchema = createInsertSchema(quickShortcuts).omit({ id: true, createdAt: true })
export const insertDockItemSchema = createInsertSchema(dockItems).omit({ id: true, createdAt: true })

// Types
export type User = typeof users.$inferSelect
export type InsertUser = z.infer<typeof insertUserSchema>
export type YoutubeVideo = typeof youtubeVideos.$inferSelect
export type InsertYoutubeVideo = z.infer<typeof insertYoutubeVideoSchema>
export type StudyNote = typeof studyNotes.$inferSelect
export type InsertStudyNote = z.infer<typeof insertStudyNoteSchema>
export type EducationalResource = typeof educationalResources.$inferSelect
export type InsertEducationalResource = z.infer<typeof insertEducationalResourceSchema>
export type GameStats = typeof gameStats.$inferSelect
export type InsertGameStats = z.infer<typeof insertGameStatsSchema>
export type MusicPlaylist = typeof musicPlaylists.$inferSelect
export type InsertMusicPlaylist = z.infer<typeof insertMusicPlaylistSchema>
export type WorkoutProgress = typeof workoutProgress.$inferSelect
export type InsertWorkoutProgress = z.infer<typeof insertWorkoutProgressSchema>
export type HealthTip = typeof healthTips.$inferSelect
export type InsertHealthTip = z.infer<typeof insertHealthTipSchema>
export type FoodScan = typeof foodScans.$inferSelect
export type InsertFoodScan = z.infer<typeof insertFoodScanSchema>
export type WatchListItem = typeof watchList.$inferSelect
export type InsertWatchListItem = z.infer<typeof insertWatchListSchema>
export type WishlistItem = typeof wishlistItems.$inferSelect
export type InsertWishlistItem = z.infer<typeof insertWishlistItemSchema>
export type Budget = typeof budgets.$inferSelect
export type InsertBudget = z.infer<typeof insertBudgetSchema>
export type Bill = typeof bills.$inferSelect
export type InsertBill = z.infer<typeof insertBillSchema>
export type Document = typeof documents.$inferSelect
export type InsertDocument = z.infer<typeof insertDocumentSchema>
export type AiTool = typeof aiTools.$inferSelect
export type InsertAiTool = z.infer<typeof insertAiToolSchema>
export type QuickShortcut = typeof quickShortcuts.$inferSelect
export type InsertQuickShortcut = z.infer<typeof insertQuickShortcutSchema>
export type DockItem = typeof dockItems.$inferSelect
export type InsertDockItem = z.infer<typeof insertDockItemSchema>